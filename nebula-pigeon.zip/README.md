# Nebula Pigeon 🚀

A simple throwaway website that just says "Hello".

## How to publish on GitHub Pages

1. Create a new repository on GitHub (e.g. `nebula-pigeon`)
2. Upload the contents of this folder (index.html and README.md)
3. Go to **Settings > Pages**
4. Under "Source", select `main` branch and root (`/`) directory
5. Click Save — your site will be live at:  
   `https://hwaydesignanddrafting.github.io/nebula-pigeon`
